/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "functions.h"

uint8 WHEEL1StepNum = 3U, WHEEL2StepNum = 3U;
extern CYBIT Timer1_DIR;
extern CYBIT Timer2_DIR;
extern CYBIT Timer1Flag;
extern CYBIT Timer2Flag;
extern uint8 WHEELY_MODE;

void WHEELY_INIT(void){
    /*Intilization Sequence of the Robot*/
    LED_B_Write(1);
    
    M1D1H_Write(0); /*Output disabled*/
    M1D1L_Write(0); /*Output disabled*/
    M1D2H_Write(0); /*Output disabled*/
    M1D2L_Write(0); /*Output disabled*/
    M1D3H_Write(0); /*Output disabled*/
    M1D3L_Write(0); /*Output disabled*/
    
    M2D1H_Write(0); /*Output disabled*/
    M2D1L_Write(0); /*Output disabled*/
    M2D2H_Write(0); /*Output disabled*/
    M2D2L_Write(0); /*Output disabled*/
    M2D3H_Write(0); /*Output disabled*/
    M2D3L_Write(0); /*Output disabled*/
    
    WHEELY_MODE = 0;
    Timer1_Stop();
    Timer2_Stop();
    
    CyDelay(500u); 
    LED_B_Write(0);
}

void WHEELY_CHANGEMODE(uint8 select_mode){ 
    Timer1_Start();
    Timer2_Start();
    if(select_mode == 1U){
        /*Driver Forward*/
        Timer1_DIR = 0;
        Timer2_DIR = 0;
    }
    else if(select_mode == 2U){
        /*Driver Left*/
        Timer1_WritePeriod(Timer1_ReadPeriod() - 3U);
        Timer2_WritePeriod(Timer2_ReadPeriod() + 3U);
    }
    else if(select_mode == 3U){
        /*Driver Right*/
        Timer1_WritePeriod(Timer1_ReadPeriod() + 3U);
        Timer2_WritePeriod(Timer2_ReadPeriod() - 3U);
    }
    else if(select_mode == 4U){
        /*Driver Backward*/
        Timer1_DIR = 1;
        Timer2_DIR = 1;
    }
    else if(select_mode == 5U){
        /*Rotate Clockwise*/
        Timer1_DIR = 1;
        Timer2_DIR = 0;
    }
    else if(select_mode == 6U){
        /*Rotate Anticlockwise*/
        Timer1_DIR = 0;
        Timer2_DIR = 1;
    }
    else{
        /*Skip*/
    }
}

void WHEELY_HANDLER(void){    
    if(Timer1Flag == 1){
        Timer1Flag = 0;
        WHEEL1_COMMUTE(Timer1_DIR);
    }
    else{
        /*Skip*/
    }
    if (Timer2Flag == 1){
        Timer2Flag = 0;
        WHEEL2_COMMUTE(Timer2_DIR);
    }
    else{
        /*Skip*/
    } 
}

void WHEEL1_COMMUTE(CYBIT M1_DIR) {
        if(M1_DIR == 0){
            WHEEL1StepNum--; /*Go to next commutation step*/
        }
        else{
            WHEEL1StepNum++; /*Go to next commutation step*/
        }
        switch (WHEEL1StepNum) {
            case 1:
                /*PH1-H = HIGH, PH2-L = HIGH, PH3 - READ*/             
                M1D1H_Write(1);
                M1D1L_Write(0);
                M1D2H_Write(0);
                M1D2L_Write(1);
                M1D3H_Write(0); 
                M1D3L_Write(0); 
                if(M1_DIR == 0){
                    WHEEL1StepNum = 7;
                }
                else{
                    /*Skip*/
                }
                break;

            case 2:
                /*PH1-H = HIGH, PH3-L = HIGH, PH2 - READ*/             
                M1D1H_Write(1);
                M1D1L_Write(0);
                M1D2H_Write(0);
                M1D2L_Write(0);
                M1D3H_Write(0); 
                M1D3L_Write(1); 
                break;

            case 3:
                /*PH2-H = HIGH, PH3-L = HIGH, PH1 - READ*/             
                M1D1H_Write(0);
                M1D1L_Write(0);
                M1D2H_Write(1);
                M1D2L_Write(0);
                M1D3H_Write(0); 
                M1D3L_Write(1); 
                break;

            case 4:
                /*PH2-H = HIGH, PH1-L = HIGH, PH3 - READ*/             
                M1D1H_Write(0);
                M1D1L_Write(1);
                M1D2H_Write(1);
                M1D2L_Write(0);
                M1D3H_Write(0); 
                M1D3L_Write(0); 
                break;

            case 5:
                /*PH3-H = HIGH, PH1-L = HIGH, PH2 - READ*/             
                M1D1H_Write(0);
                M1D1L_Write(1);
                M1D2H_Write(0);
                M1D2L_Write(0);
                M1D3H_Write(1); 
                M1D3L_Write(0); 
                break;

            case 6:
                /*PH3-H = HIGH, PH2-L = HIGH, PH1 - READ*/                
                M1D1H_Write(0);
                M1D1L_Write(0);
                M1D2H_Write(0);
                M1D2L_Write(1);
                M1D3H_Write(1); 
                M1D3L_Write(0); 
                if(M1_DIR == 1){
                    WHEEL1StepNum = 0;
                }
                else{
                    /*Skip*/
                }
                break;
        }
}

void WHEEL2_COMMUTE(CYBIT M2_DIR) {
        if(M2_DIR == 0){
            WHEEL2StepNum--; /*Go to next commutation step*/
        }
        else{
            WHEEL2StepNum++; /*Go to next commutation step*/
        }
        switch (WHEEL2StepNum) {
            case 1:
                /*PH1-H = HIGH, PH2-L = HIGH, PH3 - READ*/                
                M2D1H_Write(1);
                M2D1L_Write(0);
                M2D2H_Write(0);
                M2D2L_Write(1);
                M2D3H_Write(0); 
                M2D3L_Write(0); 
                
                if(M2_DIR == 0){
                    WHEEL2StepNum = 7;
                }
                else{
                    /*Skip*/
                }
                break;

            case 2:
                /*PH1-H = HIGH, PH3-L = HIGH, PH2 - READ*/
                M2D1H_Write(1);
                M2D1L_Write(0);
                M2D2H_Write(0);
                M2D2L_Write(0);
                M2D3H_Write(0); 
                M2D3L_Write(1); 
                break;

            case 3:
                /*PH2-H = HIGH, PH3-L = HIGH, PH1 - READ*/
                M2D1H_Write(0);
                M2D1L_Write(0);
                M2D2H_Write(1);
                M2D2L_Write(0);
                M2D3H_Write(0);
                M2D3L_Write(1);
                break;

            case 4:
                /*PH2-H = HIGH, PH1-L = HIGH, PH3 - READ*/                
                M2D1H_Write(0);
                M2D1L_Write(1);
                M2D2H_Write(1);
                M2D2L_Write(0);
                M2D3H_Write(0); 
                M2D3L_Write(0); 
                break;

            case 5:
                /*PH3-H = HIGH, PH1-L = HIGH, PH2 - READ*/
                M2D1H_Write(0);
                M2D1L_Write(1);
                M2D2H_Write(0);
                M2D2L_Write(0);
                M2D3H_Write(1); 
                M2D3L_Write(0); 
                break;

            case 6:
                /*PH3-H = HIGH, PH2-L = HIGH, PH1 - READ*/
                M2D1H_Write(0);
                M2D1L_Write(0);
                M2D2H_Write(0);
                M2D2L_Write(1);
                M2D3H_Write(1); 
                M2D3L_Write(0); 
                if(M2_DIR == 1){
                    WHEEL2StepNum = 0;
                }
                else{
                    /*Skip*/
                }
                break;
        }
}

/* [] END OF FILE */