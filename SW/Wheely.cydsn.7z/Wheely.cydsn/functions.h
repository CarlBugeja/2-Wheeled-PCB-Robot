/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

#define LIGHT_BLUE 0U
#define LIGHT_RED 1U
#define LIGHT_OFF 2U

void WHEELY_INIT(void);
void WHEELY_HANDLER(void);
void WHEEL1_COMMUTE(CYBIT M1_DIR);
void WHEEL2_COMMUTE(CYBIT M2_DIR);
void WHEELY_CHANGEMODE(uint8 select_mode);

/* [] END OF FILE */
