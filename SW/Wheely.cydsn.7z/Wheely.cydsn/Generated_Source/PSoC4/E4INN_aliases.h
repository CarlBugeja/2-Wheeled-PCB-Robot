/*******************************************************************************
* File Name: E4INN.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_E4INN_ALIASES_H) /* Pins E4INN_ALIASES_H */
#define CY_PINS_E4INN_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define E4INN_0			(E4INN__0__PC)
#define E4INN_0_PS		(E4INN__0__PS)
#define E4INN_0_PC		(E4INN__0__PC)
#define E4INN_0_DR		(E4INN__0__DR)
#define E4INN_0_SHIFT	(E4INN__0__SHIFT)
#define E4INN_0_INTR	((uint16)((uint16)0x0003u << (E4INN__0__SHIFT*2u)))

#define E4INN_INTR_ALL	 ((uint16)(E4INN_0_INTR))


#endif /* End Pins E4INN_ALIASES_H */


/* [] END OF FILE */
