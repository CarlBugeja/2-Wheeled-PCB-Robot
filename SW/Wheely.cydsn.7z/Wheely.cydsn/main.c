/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include "functions.h"

CYBLE_CONN_HANDLE_T connectionHandle;
CYBIT Timer1_DIR = 0, Timer2_DIR = 0, Timer1Flag = 0, Timer2Flag = 0;
uint8 WHEELY_MODE = 0U, WHEELY_SPEED = 0U;

CY_ISR(Timer1_Int_Handler){ 
    Timer1_ClearInterrupt(Timer1_INTR_MASK_TC);
    Timer1Flag = 1;
}

CY_ISR(Timer2_Int_Handler){ 
    Timer2_ClearInterrupt(Timer2_INTR_MASK_TC);
    Timer2Flag = 1;
}

void Stack_Handler(uint32 eventCode, void *eventParam){
    /*Generic Stack Event Handler*/
    /*Called when an event starts or when it esteblished/stops a connection */
    
    CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReq;
    switch(eventCode){
        case CYBLE_EVT_STACK_ON:
        case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
            CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);
            Timer1_Stop();
            Timer2_Stop();
            break;
        case CYBLE_EVT_GATT_CONNECT_IND:
            connectionHandle = *(CYBLE_CONN_HANDLE_T *)eventParam;
            break;
        case CYBLE_EVT_GATTS_WRITE_REQ:
            wrReq = (CYBLE_GATTS_WRITE_REQ_PARAM_T *)eventParam;
            if(CYBLE_WHEELY_MODE_CHAR_HANDLE == wrReq->handleValPair.attrHandle){                
                WHEELY_MODE = wrReq->handleValPair.value.val[0]; 
                WHEELY_CHANGEMODE(WHEELY_MODE);
            }
            else if (CYBLE_WHEELY_SPEED_CHAR_HANDLE == wrReq->handleValPair.attrHandle){              
                WHEELY_SPEED = wrReq->handleValPair.value.val[0];                  
                Timer1_WritePeriod(WHEELY_SPEED);                 
                Timer2_WritePeriod(WHEELY_SPEED);
            }
            else{
                /*Skip*/
            }
            CyBle_GattsWriteRsp(connectionHandle);
            break;
        default:
            break;
    }
}

int main (void)
{    
    Timer1_Start();
    Timer1_Int_StartEx(Timer1_Int_Handler);
    
    Timer2_Start();
    Timer2_Int_StartEx(Timer2_Int_Handler);
    
    WHEELY_INIT();       
    CyGlobalIntEnable;
    CyBle_Start(Stack_Handler); 
    
    WHEELY_CHANGEMODE(1);
    while(1){
        LED_B_Write(!LED_B_Read());
        CyBle_ProcessEvents();
        WHEELY_HANDLER();
    }
}



/* [] END OF FILE */
